#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""读数据包的三张表，打印几个常用统计。需要 pandas。"""
import pandas as pd

import os
D = os.path.dirname(os.path.abspath(__file__)) + os.sep  # 脚本和数据放同一目录即可

zt = pd.read_csv(D + '涨停明细_2021-2026.csv', parse_dates=['date'])
lb = pd.read_csv(D + '连板统计.csv')
emo = pd.read_csv(D + '情绪日度.csv', parse_dates=['date'])

print(f'涨停明细 {len(zt):,} 行，{zt.date.min().date()} ~ {zt.date.max().date()}')
print(f'每日涨停家数：均值 {emo.zt_n.mean():.1f}，最多 {emo.zt_n.max()}，最少 {emo.zt_n.min()}')

ok = zt[zt.next_close_pct.notna()]
print('\n【第几板 × 次日表现（相对当日收盘）】')
g = ok.groupby('streak').next_close_pct.agg(['count', 'mean', 'median'])
g['winrate'] = ok.groupby('streak').apply(lambda x: (x.next_close_pct > 0).mean(), include_groups=False)
print(g.head(8).round(4).to_string())

print('\n【一字板 vs 换手板（首板）】')
s1 = ok[ok.streak == 1]
for flag, name in [(1, '一字板'), (0, '换手板')]:
    s = s1[s1.is_one_word == flag]
    print(f'{name}: 样本 {len(s):,}  次日均收益 {s.next_close_pct.mean():.2%}  '
          f'次日涨停率 {s.next_is_limit.mean():.1%}')

print('\n【成交额分组（首板）】')
b = s1.copy()
b['bucket'] = pd.cut(b.amount, [0, 2e8, 5e8, 1e9, 2e9, 1e12],
                     labels=['<2亿', '2-5亿', '5-10亿', '10-20亿', '>20亿'])
print(b.groupby('bucket', observed=True).next_close_pct.agg(['count', 'mean']).round(4).to_string())

print('\n【近 20 个交易日的情绪】')
print(emo.tail(20)[['date', 'zt_n', 'lianban_n', 'one_word_n', 'max_streak', 'next_zt_rate']].to_string(index=False))
